/**
 * Contem as classes do Servico Texto-para-Fala (TTS).
 * @author Robson Martins (robson@robsonmartins.com)
 */
package com.robsonmartins.acaas.tts;