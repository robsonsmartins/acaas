/**
 * Contem as classes do Servico Fala-para-Libras (S2Libras).
 * @author Robson Martins (robson@robsonmartins.com)
 */
package com.robsonmartins.acaas.s2libras;