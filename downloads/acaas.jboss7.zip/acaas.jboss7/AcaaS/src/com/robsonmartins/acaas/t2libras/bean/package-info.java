/**
 * Contem as classes que representam entidades ou conjuntos de dados
 *  usados pelo Servico Texto-para-Libras (T2Libras).
 * @author Robson Martins (robson@robsonmartins.com)
 */
package com.robsonmartins.acaas.t2libras.bean;