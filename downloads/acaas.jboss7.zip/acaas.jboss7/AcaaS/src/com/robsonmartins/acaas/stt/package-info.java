/**
 * Contem as classes do Servico Fala-para-Texto (STT ou ASR).
 * @author Robson Martins (robson@robsonmartins.com)
 */
package com.robsonmartins.acaas.stt;