/**
 * Contem as classes do Servico Texto-para-Libras (T2Libras).
 * @author Robson Martins (robson@robsonmartins.com)
 */
package com.robsonmartins.acaas.t2libras;