/**
 * Contem as classes que manipulam os dados usados
 *   pelos Servicos de Acessibilidade (AcaaS).
 * @author Robson Martins (robson@robsonmartins.com)
 */
package com.robsonmartins.acaas.sql;