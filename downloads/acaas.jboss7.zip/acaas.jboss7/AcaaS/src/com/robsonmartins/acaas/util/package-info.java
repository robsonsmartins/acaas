/**
 * Contem as classes que implementam funcionalidades uteis aos
 *    Servicos de Acessibilidade (AcaaS).
 * @author Robson Martins (robson@robsonmartins.com)
 */
package com.robsonmartins.acaas.util;